module.exports = {
  BOT_TOKEN: "BOT_TOKEN",
};
